# 🤖 IA-Cidadão

Este projeto foi desenvolvido como parte da Imersão de IA da Alura com Google Gemini.

## ✨ Sobre

**IA-Cidadão** é um chatbot inteligente que usa a API Gemini para ajudar cidadãos com dúvidas, principalmente pessoas idosas ou com deficiência, promovendo inclusão digital e acessibilidade.

## 🚀 Como usar

1. Clone o repositório ou abra o notebook no Google Colab.
2. Instale as dependências com `pip install -r requirements.txt`.
3. Insira sua chave da API Gemini no campo indicado.
4. Rode o notebook e converse com o assistente digitando suas perguntas.

## 🧠 Tecnologias

- Python 3.11+
- Google Generative AI (Gemini 1.5 Flash)
- Google Colab

## 👩‍💻 Desenvolvido por Nathiele Aguiar
